import { theme } from '@chakra-ui/core'

export default theme
